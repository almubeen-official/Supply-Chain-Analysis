USE project_supply_chain_data;


-- 1. DATABASE OVERVIEW

SHOW TABLES;

SELECT COUNT(*) AS Total_Records
FROM supply_chain_data;

SELECT COUNT(*) AS Supplier_Records
FROM Supplier_Performance;


-- 2. DATA QUALITY CHECKS

SELECT
    SUM(`Product type` IS NULL) AS Missing_Product_Type,
    SUM(SKU IS NULL) AS Missing_SKU,
    SUM(Price IS NULL) AS Missing_Price,
    SUM(`Number of products sold` IS NULL) AS Missing_Products_Sold,
    SUM(`Revenue generated` IS NULL) AS Missing_Revenue,
    SUM(`Supplier name` IS NULL) AS Missing_Supplier,
    SUM(`Inspection results` IS NULL) AS Missing_Inspection,
    SUM(`Defect rates` IS NULL) AS Missing_Defect_Rate
FROM supply_chain_data;

SELECT
    SKU,
    COUNT(*) AS Duplicate_Count
FROM supply_chain_data
GROUP BY SKU
HAVING COUNT(*) > 1;

SELECT *
FROM supply_chain_data
WHERE Price < 0
   OR Availability < 0
   OR `Number of products sold` < 0
   OR `Revenue generated` < 0
   OR `Stock levels` < 0
   OR `Order quantities` < 0
   OR `Shipping times` < 0
   OR `Shipping costs` < 0
   OR `Manufacturing costs` < 0
   OR `Defect rates` < 0
   OR Costs < 0;

SELECT
    `Inspection results`,
    COUNT(*) AS Total_Products
FROM supply_chain_data
GROUP BY `Inspection results`
ORDER BY Total_Products DESC;


-- 3. PRODUCT AND REVENUE ANALYSIS

SELECT
    `Product type`,
    COUNT(*) AS Total_SKUs,
    SUM(`Number of products sold`) AS Total_Products_Sold,
    ROUND(SUM(`Revenue generated`), 2) AS Total_Revenue,
    ROUND(AVG(`Revenue generated`), 2) AS Average_Revenue
FROM supply_chain_data
GROUP BY `Product type`
ORDER BY Total_Revenue DESC;

SELECT
    SKU,
    `Product type`,
    `Number of products sold`,
    ROUND(`Revenue generated`, 2) AS Revenue
FROM supply_chain_data
ORDER BY `Revenue generated` DESC
LIMIT 10;

SELECT
    SKU,
    `Product type`,
    `Number of products sold`
FROM supply_chain_data
ORDER BY `Number of products sold` DESC
LIMIT 10;

SELECT
    `Product type`,
    ROUND(AVG(Price), 2) AS Average_Price
FROM supply_chain_data
GROUP BY `Product type`
ORDER BY Average_Price DESC;

SELECT
    ROUND(SUM(`Revenue generated`), 2) AS Total_Revenue,
    SUM(`Number of products sold`) AS Total_Products_Sold,
    ROUND(AVG(`Revenue generated`), 2) AS Average_Revenue_Per_SKU
FROM supply_chain_data;


-- 4. INVENTORY AND STOCK ANALYSIS

SELECT
    `Product type`,
    SUM(`Stock levels`) AS Total_Stock,
    SUM(Availability) AS Total_Availability,
    SUM(`Order quantities`) AS Total_Order_Quantity
FROM supply_chain_data
GROUP BY `Product type`
ORDER BY Total_Stock DESC;

SELECT
    SKU,
    `Product type`,
    `Stock levels`,
    Availability,
    `Number of products sold`
FROM supply_chain_data
WHERE `Stock levels` <= 10
ORDER BY `Stock levels` ASC;

SELECT
    SKU,
    `Product type`,
    `Stock levels`,
    `Number of products sold`
FROM supply_chain_data
WHERE `Stock levels` >= 80
ORDER BY `Stock levels` DESC;

SELECT
    SKU,
    `Product type`,
    `Stock levels`,
    `Order quantities`,
    (`Stock levels` - `Order quantities`) AS Stock_Order_Difference
FROM supply_chain_data
ORDER BY Stock_Order_Difference ASC;


-- 5. SUPPLIER ANALYSIS

SELECT
    `Supplier name`,
    COUNT(*) AS Total_SKUs,
    ROUND(AVG(`Lead times`), 2) AS Average_Lead_Times,
    ROUND(AVG(`Manufacturing costs`), 2) AS Average_Manufacturing_Cost,
    ROUND(AVG(`Defect rates`), 2) AS Average_Defect_Rate,
    ROUND(AVG(`Shipping costs`), 2) AS Average_Shipping_Cost
FROM supply_chain_data
GROUP BY `Supplier name`
ORDER BY Average_Lead_Times ASC;

SELECT
    Supplier_Name,
    Cost_per_Unit_INR,
    Lead_Time_Days,
    Defect_Rate_Percent
FROM Supplier_Performance
ORDER BY Defect_Rate_Percent ASC;


-- 6. SUPPLIER RANKING (COMPATIBLE ALTERNATIVE TO RANK())

SELECT
    s1.Supplier_Name,
    s1.Cost_per_Unit_INR,
    s1.Lead_Time_Days,
    s1.Defect_Rate_Percent,
    (
        SELECT COUNT(*) + 1
        FROM Supplier_Performance AS s2
        WHERE s2.Defect_Rate_Percent < s1.Defect_Rate_Percent
           OR (
                s2.Defect_Rate_Percent = s1.Defect_Rate_Percent
                AND s2.Lead_Time_Days < s1.Lead_Time_Days
           )
           OR (
                s2.Defect_Rate_Percent = s1.Defect_Rate_Percent
                AND s2.Lead_Time_Days = s1.Lead_Time_Days
                AND s2.Cost_per_Unit_INR < s1.Cost_per_Unit_INR
           )
    ) AS Supplier_Rank
FROM Supplier_Performance AS s1
ORDER BY Supplier_Rank;


-- 7. SHIPPING AND LOGISTICS ANALYSIS

SELECT
    `Shipping carriers`,
    COUNT(*) AS Total_Records,
    ROUND(AVG(`Shipping times`), 2) AS Average_Shipping_Time,
    ROUND(AVG(`Shipping costs`), 2) AS Average_Shipping_Cost,
    ROUND(SUM(`Shipping costs`), 2) AS Total_Shipping_Cost
FROM supply_chain_data
GROUP BY `Shipping carriers`
ORDER BY Average_Shipping_Time ASC;

SELECT
    `Transportation modes`,
    COUNT(*) AS Total_Records,
    ROUND(AVG(`Shipping times`), 2) AS Average_Shipping_Time,
    ROUND(AVG(`Shipping costs`), 2) AS Average_Shipping_Cost
FROM supply_chain_data
GROUP BY `Transportation modes`
ORDER BY Average_Shipping_Cost ASC;

SELECT
    Routes,
    COUNT(*) AS Total_Records,
    ROUND(AVG(Costs), 2) AS Average_Route_Cost,
    ROUND(SUM(Costs), 2) AS Total_Route_Cost
FROM supply_chain_data
GROUP BY Routes
ORDER BY Average_Route_Cost ASC;

SELECT
    Location,
    COUNT(*) AS Total_SKUs,
    ROUND(AVG(`Shipping times`), 2) AS Average_Shipping_Time,
    ROUND(AVG(`Shipping costs`), 2) AS Average_Shipping_Cost,
    ROUND(SUM(`Revenue generated`), 2) AS Total_Revenue
FROM supply_chain_data
GROUP BY Location
ORDER BY Total_Revenue DESC;


-- 8. MANUFACTURING ANALYSIS

SELECT
    `Product type`,
    SUM(`Production volumes`) AS Total_Production,
    ROUND(AVG(`Manufacturing lead time`), 2)
        AS Average_Manufacturing_Lead_Time,
    ROUND(AVG(`Manufacturing costs`), 2)
        AS Average_Manufacturing_Cost
FROM supply_chain_data
GROUP BY `Product type`
ORDER BY Average_Manufacturing_Cost ASC;

SELECT
    SKU,
    `Product type`,
    `Production volumes`,
    `Manufacturing lead time`,
    ROUND(`Manufacturing costs`, 2) AS Manufacturing_Cost
FROM supply_chain_data
ORDER BY `Manufacturing costs` DESC
LIMIT 10;

SELECT
    `Supplier name`,
    ROUND(AVG(`Manufacturing lead time`), 2)
        AS Average_Manufacturing_Lead_Time,
    ROUND(AVG(`Manufacturing costs`), 2)
        AS Average_Manufacturing_Cost
FROM supply_chain_data
GROUP BY `Supplier name`
ORDER BY Average_Manufacturing_Lead_Time ASC;


-- 9. QUALITY AND DEFECT ANALYSIS

SELECT
    `Inspection results`,
    COUNT(*) AS Total_Products,
    ROUND(
        COUNT(*) * 100.0 /
        (SELECT COUNT(*) FROM supply_chain_data),
        2
    ) AS Percentage
FROM supply_chain_data
GROUP BY `Inspection results`
ORDER BY Total_Products DESC;

SELECT
    `Product type`,
    ROUND(AVG(`Defect rates`), 2) AS Average_Defect_Rate,
    MAX(`Defect rates`) AS Maximum_Defect_Rate,
    MIN(`Defect rates`) AS Minimum_Defect_Rate
FROM supply_chain_data
GROUP BY `Product type`
ORDER BY Average_Defect_Rate DESC;

SELECT
    SKU,
    `Product type`,
    `Supplier name`,
    `Inspection results`,
    `Defect rates`
FROM supply_chain_data
ORDER BY `Defect rates` DESC
LIMIT 10;

SELECT
    `Supplier name`,
    `Inspection results`,
    COUNT(*) AS Total_Products
FROM supply_chain_data
GROUP BY `Supplier name`, `Inspection results`
ORDER BY `Supplier name`, Total_Products DESC;


-- 10. LEAD TIME ANALYSIS

SELECT
    `Supplier name`,
    ROUND(AVG(`Lead times`), 2) AS Average_Lead_Times,
    ROUND(AVG(`Lead time`), 2) AS Average_Lead_Time
FROM supply_chain_data
GROUP BY `Supplier name`
ORDER BY Average_Lead_Times ASC;

SELECT
    `Product type`,
    ROUND(AVG(`Lead times`), 2) AS Average_Lead_Times,
    ROUND(AVG(`Lead time`), 2) AS Average_Lead_Time,
    ROUND(AVG(`Manufacturing lead time`), 2)
        AS Average_Manufacturing_Lead_Time
FROM supply_chain_data
GROUP BY `Product type`
ORDER BY Average_Lead_Times ASC;

SELECT
    SKU,
    `Product type`,
    `Shipping carriers`,
    `Shipping times`,
    Routes
FROM supply_chain_data
ORDER BY `Shipping times` DESC
LIMIT 10;


-- 11. FINAL BUSINESS SUMMARY

SELECT
    COUNT(*) AS Total_SKUs,
    COUNT(DISTINCT `Product type`) AS Total_Product_Categories,
    COUNT(DISTINCT `Supplier name`) AS Total_Suppliers,
    ROUND(SUM(`Revenue generated`), 2) AS Total_Revenue,
    SUM(`Number of products sold`) AS Total_Products_Sold,
    ROUND(AVG(`Shipping times`), 2) AS Average_Shipping_Time,
    ROUND(AVG(`Shipping costs`), 2) AS Average_Shipping_Cost,
    ROUND(AVG(`Manufacturing costs`), 2) AS Average_Manufacturing_Cost,
    ROUND(AVG(`Defect rates`), 2) AS Average_Defect_Rate
FROM supply_chain_data;

SELECT
    `Product type`,
    ROUND(SUM(`Revenue generated`), 2) AS Total_Revenue
FROM supply_chain_data
GROUP BY `Product type`
ORDER BY Total_Revenue DESC
LIMIT 1;

SELECT
    `Product type`,
    ROUND(AVG(`Defect rates`), 2) AS Average_Defect_Rate
FROM supply_chain_data
GROUP BY `Product type`
ORDER BY Average_Defect_Rate DESC
LIMIT 1;

SELECT
    `Shipping carriers`,
    ROUND(AVG(`Shipping costs`), 2) AS Average_Shipping_Cost
FROM supply_chain_data
GROUP BY `Shipping carriers`
ORDER BY Average_Shipping_Cost ASC
LIMIT 1;

SELECT
    `Supplier name`,
    ROUND(AVG(`Lead times`), 2) AS Average_Lead_Times
FROM supply_chain_data
GROUP BY `Supplier name`
ORDER BY Average_Lead_Times ASC
LIMIT 1;

-------------------------
